#define USERNAME "01Space"
#define DEVICE_ID "XYX2022427"
#define DEVICE_CREDENTIAL "phmxyx0324"

#define SSID "iPhone"
#define SSID_PASSWORD "8888888888"
